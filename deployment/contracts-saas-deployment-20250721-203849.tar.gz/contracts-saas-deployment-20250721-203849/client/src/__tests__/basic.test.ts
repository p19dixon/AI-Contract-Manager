// Basic test to verify Jest setup
describe('Basic Test Suite', () => {
  it('should run a basic test', () => {
    expect(true).toBe(true)
  })

  it('should perform basic math', () => {
    expect(2 + 2).toBe(4)
  })
})