-- Add company field to customers table
ALTER TABLE customers ADD COLUMN company TEXT;